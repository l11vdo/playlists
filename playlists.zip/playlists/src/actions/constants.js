export const AUTHENDPOINT = 'https://accounts.spotify.com/authorize';
export const CLIENTID = 'ac3e9e025b2b41679d3f209e7d4e57e7';    // make this yours!
export const REDIRECTURI = 'http://localhost:3000/callback/';
export const SCOPES = [ 'user-top-read', 'playlist-read-private', 'playlist-modify-public', 'playlist-modify-private' ];
